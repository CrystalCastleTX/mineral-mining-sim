THREE.OrbitControls=function(object,domElement){this.object=object;this.domElement=domElement;this.update=function(){}};
